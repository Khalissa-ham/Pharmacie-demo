import React, { useState } from 'react';
import { Upload, Check } from 'lucide-react';

export default function PrescriptionUpload() {
  const [isDragging, setIsDragging] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setIsDragging(true);
    } else if (e.type === "dragleave") {
      setIsDragging(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const files = e.dataTransfer.files;
    if (files && files[0]) {
      setUploadedFile(files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files[0]) {
      setUploadedFile(files[0]);
    }
  };

  return (
    <section className="py-16 bg-gray-50" id="ordonnance">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Envoyez votre ordonnance</h2>
          <p className="text-lg text-gray-600">
            Transmettez-nous votre ordonnance en toute sécurité
          </p>
        </div>

        <div className="max-w-xl mx-auto">
          <div
            className={`border-2 border-dashed rounded-lg p-8 text-center ${
              isDragging ? "border-emerald-500 bg-emerald-50" : "border-gray-300"
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            {!uploadedFile ? (
              <>
                <Upload className="mx-auto h-12 w-12 text-gray-400" />
                <p className="mt-4 text-gray-600">
                  Glissez votre ordonnance ici ou
                  <label className="ml-1 text-emerald-600 hover:text-emerald-500 cursor-pointer">
                    parcourez vos fichiers
                    <input
                      type="file"
                      className="hidden"
                      accept="image/*,.pdf"
                      onChange={handleFileInput}
                    />
                  </label>
                </p>
                <p className="mt-2 text-sm text-gray-500">
                  PNG, JPG ou PDF jusqu'à 10MB
                </p>
              </>
            ) : (
              <div className="text-center">
                <Check className="mx-auto h-12 w-12 text-emerald-500" />
                <p className="mt-2 text-emerald-600">{uploadedFile.name}</p>
                <button
                  onClick={() => setUploadedFile(null)}
                  className="mt-4 text-sm text-red-600 hover:text-red-500"
                >
                  Supprimer
                </button>
              </div>
            )}
          </div>

          <button
            className={`mt-6 w-full py-3 px-4 rounded-lg text-white font-medium ${
              uploadedFile
                ? "bg-emerald-600 hover:bg-emerald-700"
                : "bg-gray-400 cursor-not-allowed"
            }`}
            disabled={!uploadedFile}
          >
            Envoyer l'ordonnance
          </button>
        </div>
      </div>
    </section>
  );
}