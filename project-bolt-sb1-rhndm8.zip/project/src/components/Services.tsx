import React from 'react';
import { FileText, ShoppingBag, MessageCircle, Sparkles, Tag, BookOpen } from 'lucide-react';

const services = [
  {
    icon: FileText,
    title: "Envoi d'ordonnance",
    description: "Transmettez votre ordonnance en ligne pour un traitement rapide"
  },
  {
    icon: ShoppingBag,
    title: "Click & Collect",
    description: "Commandez en ligne et retirez en pharmacie sous 2h"
  },
  {
    icon: MessageCircle,
    title: "Conseils personnalisés",
    description: "Bénéficiez de l'expertise de nos pharmaciens"
  },
  {
    icon: Sparkles,
    title: "Espace cosmétiques",
    description: "Découvrez notre sélection de produits de beauté"
  },
  {
    icon: Tag,
    title: "Promotions",
    description: "Profitez de nos offres exclusives"
  },
  {
    icon: BookOpen,
    title: "Blog santé",
    description: "Informez-vous sur les dernières actualités santé"
  }
];

export default function Services() {
  return (
    <section className="py-16 bg-white" id="services">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Nos Services</h2>
          <p className="text-lg text-gray-600">Découvrez tout ce que nous pouvons faire pour vous</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <div key={index} className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300">
                <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center mb-4">
                  <Icon className="h-6 w-6 text-emerald-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{service.title}</h3>
                <p className="text-gray-600">{service.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}