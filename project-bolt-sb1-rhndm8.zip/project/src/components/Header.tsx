import React from 'react';
import { ShoppingCart, User, Menu, X, Phone } from 'lucide-react';
import { useState } from 'react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-md fixed w-full top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <span className="text-emerald-600 text-2xl font-bold">PharmaDirect</span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <a href="#ordonnance" className="text-gray-700 hover:text-emerald-600">Ordonnance</a>
            <a href="#click-collect" className="text-gray-700 hover:text-emerald-600">Click & Collect</a>
            <a href="#conseils" className="text-gray-700 hover:text-emerald-600">Conseils</a>
            <a href="#cosmetiques" className="text-gray-700 hover:text-emerald-600">Cosmétiques</a>
            <a href="#promotions" className="text-gray-700 hover:text-emerald-600">Promotions</a>
            <a href="#blog" className="text-gray-700 hover:text-emerald-600">Blog Santé</a>
          </nav>

          <div className="flex items-center space-x-4">
            <a href="tel:+33123456789" className="hidden md:flex items-center text-gray-700 hover:text-emerald-600">
              <Phone className="h-5 w-5 mr-2" />
              <span>01 23 45 67 89</span>
            </a>
            <button className="text-gray-700 hover:text-emerald-600">
              <User className="h-6 w-6" />
            </button>
            <button className="text-gray-700 hover:text-emerald-600">
              <ShoppingCart className="h-6 w-6" />
            </button>
            <button 
              className="md:hidden text-gray-700"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <a href="#ordonnance" className="block px-3 py-2 text-gray-700 hover:text-emerald-600">Ordonnance</a>
            <a href="#click-collect" className="block px-3 py-2 text-gray-700 hover:text-emerald-600">Click & Collect</a>
            <a href="#conseils" className="block px-3 py-2 text-gray-700 hover:text-emerald-600">Conseils</a>
            <a href="#cosmetiques" className="block px-3 py-2 text-gray-700 hover:text-emerald-600">Cosmétiques</a>
            <a href="#promotions" className="block px-3 py-2 text-gray-700 hover:text-emerald-600">Promotions</a>
            <a href="#blog" className="block px-3 py-2 text-gray-700 hover:text-emerald-600">Blog Santé</a>
          </div>
        </div>
      )}
    </header>
  );
}